#!/bin/bash

curl -k https://kong-staging.istio.dev1.eks.openshiftlabs.net/amazin/health

curl -k https://kong-staging.istio.dev1.eks.openshiftlabs.net/products/all

curl -k https://kong-staging.istio.dev1.eks.openshiftlabs.net/amazin/products/all